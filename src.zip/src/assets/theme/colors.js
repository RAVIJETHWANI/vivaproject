export default {
    primary: '#b5d3e2',
    secondary: '#358bc0',
    danger: '#f72585',
    success: '#339f07',
    grey: '#adb5bd',
    white: '#ffffff',
    button : '#358bc0',
    arrow: '#1d3aa5',
    off_button : '#beb3b3' ,
    link : '#76a7e8' ,
    setting_text : '#080808',
    black: '#000000' ,
    accent: '#4895ef',
    textColor:'#368dc2'
  };