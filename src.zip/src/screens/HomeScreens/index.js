import HomeScreen from './Home/HomeScreen';

module.exports = {
  HomeScreen
}