import LoginScreen from './Login/LoginScreen';
import RegisterScreen from './Register/RegisterScreen';
import UserTypeScreen from './UserType/UserTypeScreen';



module.exports = {
  LoginScreen,
  RegisterScreen ,
  UserTypeScreen
}