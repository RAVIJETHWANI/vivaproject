const images = {
    logo: require('../assets/images/logo.png'),
    // staticBackImage: require('../assets/user-backgrounds/img1.jpeg')
}


export default images;