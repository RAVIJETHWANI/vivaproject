// AUTH SCREEN
export const USER_TYPE_SCREEN = 'User Type Screen';
export const LOGIN_SCREEN= 'Login Screen';
export const REGISTER_SCREEN= 'Register Screen';
export const OTP_SCREEN= 'Otp Screen';
export const FORGOT_PASSWORD = 'Forgot Password';




// HOME SCREEN

